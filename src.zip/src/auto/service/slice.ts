export type Slice<T> = {
    readonly content: T[];
    readonly totalElements: number;
};
