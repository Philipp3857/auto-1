import { Auto } from './auto.entity.js';
import { AutoFile } from './autoFile.entity.js';
import { Motor } from './motor.entity.js';
import { Reperatur } from './reperatur.entity.js';

export const entities = [Reperatur, Auto, AutoFile, Motor];
